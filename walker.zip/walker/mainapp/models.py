from django.db import models
from django.utils import timezone

class ProductCat(models.Model):
    category_id = models.AutoField(primary_key=True)
    name= models.CharField(max_length=50,default="")

    def __str__(self):
        return self.name

class Product(models.Model):
    product_name = models.CharField(max_length=50)
    category = models.ForeignKey(ProductCat,on_delete=models.CASCADE,default=1)
    price = models.IntegerField(default=0)
    desc = models.CharField(max_length=300)
    image = models.ImageField(upload_to="images", default="")

    def __str__(self):
        return self.product_name
    
class Orders(models.Model):
    order_id= models.AutoField(primary_key=True)
    items_json= models.CharField(max_length=5000)
    name=models.CharField(max_length=90)
    email=models.CharField(max_length=111)
    address=models.CharField(max_length=111)
    phone = models.CharField(max_length=15,default=0)
